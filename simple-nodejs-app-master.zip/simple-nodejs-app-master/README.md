# simple-nodejs-ap


with nodejs
express with ejs template 
mongodb with mongoose



download it 
npm install 
npm install mongoose


enjoy

by rohan arihant
